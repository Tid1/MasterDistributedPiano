﻿namespace MasterDistributedPiano.SuperColliderZeugs;

public enum DeviceRole {
    Host,
    Client,
    Speaker,
}